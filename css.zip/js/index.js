$('.slider__container').slick({
    dots: true,
})